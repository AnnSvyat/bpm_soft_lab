define("DvpPicsaf481a1fSection", [], function() {
	return {
		entitySchemaName: "DvpPics",
		details: /**SCHEMA_DETAILS*/{}/**SCHEMA_DETAILS*/,
		diff: /**SCHEMA_DIFF*/[]/**SCHEMA_DIFF*/,
		methods: {
			
			getMyButtonEnabled: function(){
				return true;
			},
			
		}
	};
});
